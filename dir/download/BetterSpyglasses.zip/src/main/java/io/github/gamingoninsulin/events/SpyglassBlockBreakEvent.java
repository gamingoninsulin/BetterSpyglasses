package io.github.gamingoninsulin.events;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class SpyglassBlockBreakEvent implements Listener {

    @EventHandler
    public void SkyBlockBreak(PlayerInteractEvent e) {
        Player player = e.getPlayer();
        Block block = e.getClickedBlock();

        // (new ItemStack(Material.SPYGLASS))
        if (player.getInventory().getItemInMainHand().getType() == Material.SPYGLASS){
            // checks if the player uses left click block with spyglass
            if (e.getAction().equals(Action.RIGHT_CLICK_AIR ) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
                // gets the block and change it to another block.
                if (e.getClickedBlock().getType() == Material.GRASS) {
                    // checks if the block is !null
                    if (e.getClickedBlock() != null ) {
                        // if the click block is grass changes the block
                        // to gold block
                        block.setType(Material.GOLD_BLOCK);
                    } else {
                        player.sendMessage(ChatColor.RED + "you must look at something");
                    }

                }
            }
        }
    }
}
