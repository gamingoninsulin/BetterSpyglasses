package io.github.gamingoninsulin.events;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.HashSet;

public class SpyglassEvents implements Listener {

    @EventHandler
    public void SkyBlockBreak(PlayerInteractEvent playerEvent) {
        // create player
        Player player = playerEvent.getPlayer();
        Block block = player.getTargetBlock(null,128);

        // checks if the player has a spyglass
        if (player.getInventory().getItemInMainHand().getType() == Material.SPYGLASS){

            // checks if the player uses left click block with spyglass
            if (playerEvent.getAction().equals(Action.RIGHT_CLICK_AIR ) || playerEvent.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {

                // gets the block and change it to another block.
                // currently place the block above me xD
                block.setType(Material.GOLD_BLOCK);
            }
        }
    }
}